library("tools")
maj.version <- Sys.getenv("maj.version")
maj.version <- unlist(strsplit(maj.version, "\\+"))
fields <- c("Package", "Bundle", "Priority", "Version", 
            "Depends", "Suggests", "Imports", "Contains", "Enhances", "LinkingTo", "Archs")
for(i in maj.version){
    windir <- file.path("d:\\Rcompile\\CRANpkg\\win", i, fsep="\\")
    write_PACKAGES(dir = windir, fields = fields, type = "win.binary")
}

#windir <- "d:\\Rcompile\\CRANpkg\\win64\\2.13"
#write_PACKAGES(dir = windir, fields = fields, type = "win.binary")
